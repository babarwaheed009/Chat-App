import React, { useEffect, useState } from 'react'
import ScrollToBottom from "react-scroll-to-bottom";
function Chat({ socket, username, room }) {
    const [currentMessage, setMessage] = useState("");
    const [messageList, setMessageList] = useState([]);
    const sendMessage = async () => {
        if (currentMessage !== "") {
            let message = {
                username,
                room,
                time: new Date().getHours() + ':' + new Date().getMinutes(),
                'message': currentMessage
            };
            await socket.emit('send_message', message)
            setMessageList(list => [...list, message])
        }
    }

    useEffect(() => {
        let run = true;
        if (run) {
            socket.on('receive_message', (data) => {
                console.log(data);
                setMessageList(list => [...list, data]);
            })
        }
        return () => {
            run = false
        }
    }, [socket])
    return (
        <div className="chat-window">
            <div className="chat-header">
                <p>Live Chat</p>
            </div>
            <div className="chat-body">
                <ScrollToBottom className="message-container">
                    {messageList.map((messageContent, index) => {
                        return (
                            <div key={index}
                                className="message"
                                id={username === messageContent.username ? "you" : "other"}
                            >
                                <div>
                                    <div className="message-content">
                                        <p>{messageContent.message}</p>
                                    </div>
                                    <div className="message-meta">
                                        <p id="time">{messageContent.time}</p>
                                        <p id="author">{messageContent.username}</p>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </ScrollToBottom>
            </div>
            <div className="chat-footer">
                <input
                    type="text"
                    value={currentMessage}
                    placeholder="Hey..."
                    onChange={(event) => {
                        setMessage(event.target.value);
                    }}
                    onKeyPress={(event) => {
                        event.key === "Enter" && sendMessage();
                    }}
                />
                <button onClick={sendMessage}>&#9658;</button>
            </div>
        </div>
    )
}

export default Chat